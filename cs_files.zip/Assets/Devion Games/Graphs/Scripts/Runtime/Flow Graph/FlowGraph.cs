﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames.Graphs
{
    [System.Serializable]
    public class FlowGraph : Graph
    {

    }
}