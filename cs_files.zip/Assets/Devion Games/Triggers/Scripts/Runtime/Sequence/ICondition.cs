﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames
{
    public interface ICondition : IAction
    {
     
    }
}