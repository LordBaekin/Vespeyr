﻿namespace DevionGames
{
    public enum ActionStatus
    {
        Inactive,
        Failure,
        Success,
        Running
    }
}