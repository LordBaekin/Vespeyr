﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DevionGames.StatSystem
{
    public class StatPickerAttribute : PropertyAttribute
    {
    }
}